package com.example.asynctask;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button btn_xuli;
    TextView txt_thongtin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_xuli = (Button)  findViewById(R.id.Button_xuli);
        txt_thongtin = (TextView)  findViewById(R.id.textView_infor);

        btn_xuli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Congviec().execute();
            }
        });

    }

    private class Congviec extends AsyncTask<Void, String, String>{

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            txt_thongtin.setText("Start!"+"\n");
        }

        @Override
        protected String doInBackground(Void... voids) {

            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            for (int i = 1; i <=10 ; i++) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                publishProgress("Loading " + (i*10) + " %" +"\n");
            }
            return "Done!\n";
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            txt_thongtin.append(s);
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            txt_thongtin.append(values[0]);
        }
    }

}