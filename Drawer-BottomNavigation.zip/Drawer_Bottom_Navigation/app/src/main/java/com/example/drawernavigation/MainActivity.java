package com.example.drawernavigation;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;
import android.view.MenuItem;

import com.example.drawernavigation.databinding.ActivityMainBinding;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding binding;
    private ViewPager2Adapter viewPager2Adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        viewPager2Adapter = new ViewPager2Adapter(this); // khởi tạo adapter
        binding.viewPager2.setAdapter(viewPager2Adapter); // set adapter cho viewpager

        setSupportActionBar(binding.toolbar);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, binding.drawerLayout, binding.toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);

        binding.drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        //replaceFragment(new HomeFragment());
        binding.navView.getMenu().findItem(R.id.home).setChecked(true);
        binding.bottomNav.getMenu().findItem(R.id.bottom_home).setChecked(true);


        binding.navView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                int id = item.getItemId();

                if (id==R.id.home){
                    binding.viewPager2.setCurrentItem(0);
                    binding.bottomNav.getMenu().findItem(R.id.bottom_home).setChecked(true);
                    binding.navView.getMenu().findItem(R.id.home).setChecked(true);
                    binding.navView.getMenu().findItem(R.id.gallery).setChecked(false);
                    binding.navView.getMenu().findItem(R.id.favorite).setChecked(false);
                } else if (id==R.id.gallery) {
                    binding.viewPager2.setCurrentItem(1);
                    binding.bottomNav.getMenu().findItem(R.id.bottom_gallery).setChecked(true);
                    binding.navView.getMenu().findItem(R.id.gallery).setChecked(true);
                    binding.navView.getMenu().findItem(R.id.home).setChecked(false);
                    binding.navView.getMenu().findItem(R.id.favorite).setChecked(false);
                }
                else if (id==R.id.favorite) {
                    binding.viewPager2.setCurrentItem(2);
                    binding.bottomNav.getMenu().findItem(R.id.bottom_favorite).setChecked(true);
                    binding.navView.getMenu().findItem(R.id.favorite).setChecked(true);
                    binding.navView.getMenu().findItem(R.id.home).setChecked(false);
                    binding.navView.getMenu().findItem(R.id.gallery).setChecked(false);
                }

                binding.drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });

        binding.bottomNav.setOnItemSelectedListener(item -> {

            int id = item.getItemId();

            if (id==R.id.bottom_home){
                binding.viewPager2.setCurrentItem(0);
                binding.navView.getMenu().findItem(R.id.home).setChecked(true);
                binding.navView.getMenu().findItem(R.id.gallery).setChecked(false);
                binding.navView.getMenu().findItem(R.id.favorite).setChecked(false);

            } else if (id==R.id.bottom_gallery) {
                binding.viewPager2.setCurrentItem(1);
                binding.navView.getMenu().findItem(R.id.gallery).setChecked(true);
                binding.navView.getMenu().findItem(R.id.home).setChecked(false);
                binding.navView.getMenu().findItem(R.id.favorite).setChecked(false);
            }
            else if (id==R.id.bottom_favorite){
                binding.viewPager2.setCurrentItem(2);
                binding.navView.getMenu().findItem(R.id.favorite).setChecked(true);
                binding.navView.getMenu().findItem(R.id.home).setChecked(false);
                binding.navView.getMenu().findItem(R.id.gallery).setChecked(false);

            }
            return true;
        });

        binding.viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                switch (position){
                    case 0:
                        binding.bottomNav.getMenu().findItem(R.id.bottom_home).setChecked(true);
                        binding.navView.getMenu().findItem(R.id.home).setChecked(true);
                        binding.navView.getMenu().findItem(R.id.gallery).setChecked(false);
                        binding.navView.getMenu().findItem(R.id.favorite).setChecked(false);
                        break;

                    case 1:
                        binding.bottomNav.getMenu().findItem(R.id.bottom_gallery).setChecked(true);
                        binding.navView.getMenu().findItem(R.id.gallery).setChecked(true);
                        binding.navView.getMenu().findItem(R.id.home).setChecked(false);
                        binding.navView.getMenu().findItem(R.id.favorite).setChecked(false);
                        break;

                    case 2:
                        binding.bottomNav.getMenu().findItem(R.id.bottom_favorite).setChecked(true);
                        binding.navView.getMenu().findItem(R.id.favorite).setChecked(true);
                        binding.navView.getMenu().findItem(R.id.home).setChecked(false);
                        binding.navView.getMenu().findItem(R.id.gallery).setChecked(false);
                        break;
                }
            }
        });
    }

}