package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Khai báo các biến sử dụng

    SeekBar seekBar;

    ProgressBar prB1, prB2;

    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // gán các biến vào phần tử tương ứng

        seekBar = (SeekBar) findViewById(R.id.seekBar);

        prB1 = (ProgressBar)   findViewById(R.id.progressBar);
        prB2    =   (ProgressBar)   findViewById(R.id.progressBar2);

        btn = (Button)  findViewById(R.id.button);

        prB2.setVisibility(View.INVISIBLE);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // tạo 1 sự kiện cho SeekBar

            int seekbarProgressValue = 0; // Đây là một biến được khai báo để lưu trữ giá trị hiện tại của SeekBar. Ban đầu, giá trị này được đặt là 0.
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) { // Đây là phương thức được gọi khi giá trị của SeekBar thay đổi. Trong trường hợp này, nó gán giá trị mới của SeekBar vào biến seekbarProgressValue.
                seekbarProgressValue = i;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { //  Phương thức này được gọi khi người dùng bắt đầu chạm vào SeekBar. Trong trường hợp này, không có hành động cụ thể nào được thực hiện.

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { //
                Toast.makeText(MainActivity.this, "Âm lương hiện tại: " + seekbarProgressValue, Toast.LENGTH_SHORT).show(); // Hiện thị nhanh lên màn hình số âm lượng hiện tại
            }


        });


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int current = prB1.getProgress(); // tạo 1 biến current = với thông số hiện tại của ProgressBar
                if (current >= 100){
                    current = 0;
                } // Nếu mà current = 100 thì sẽ quay về = 0


                // circle
                prB2.setVisibility(View.VISIBLE);

                // Tăng 10 mỗi 1 click

                prB1.setProgress(current + 10);
            }
        });


    }
}