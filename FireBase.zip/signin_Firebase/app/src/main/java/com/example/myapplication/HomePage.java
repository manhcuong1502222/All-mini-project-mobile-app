package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HomePage extends AppCompatActivity {

    // khai báo tên biến
    Button logOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        // tham chiến đến phần tử  tương ứng
        logOut = findViewById(R.id.logout);

        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomePage.this, MainActivity.class); //  Đây là cách bạn tạo một Intent để chuyển từ HomePage đến MainActivity.
                startActivity(intent); // Đây là cách bạn bắt đầu một hoạt động mới sử dụng Intent, tức là MainActivity.
                finish(); //  Đây là cách bạn kết thúc (finish) hoạt động hiện tại, trong trường hợp này, là HomePage.
            }
        });

    }
}