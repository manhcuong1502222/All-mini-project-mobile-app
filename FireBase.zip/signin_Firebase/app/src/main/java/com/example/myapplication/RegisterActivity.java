package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {

    //Khai báo các biến sử dụng
    TextInputEditText editTextEmail, editTextPassword;

    Button signUp;

    TextView signIn;

    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();  // Đây là cách bạn tạo một thể hiện của Firebase Authentication.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // tham chiếu các biến đến các phần tử tương ứng

        editTextEmail = findViewById(R.id.email);
        editTextPassword = findViewById(R.id.password);
        signIn = findViewById(R.id.signin);
        signUp = findViewById(R.id.signup);


        // Khi người dùng nhấn vào nút "Đăng nhập", sự kiện onClick sẽ được kích hoạt. Trong trường hợp này, nó tạo một Intent để chuyển từ RegisterActivity đến MainActivity.
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });


        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Lấy giá trị email và password từ các trường văn bản.
                String email, password;
                email = String.valueOf(editTextEmail.getText());
                password = String.valueOf(editTextPassword.getText());

                // Kiểm tra xem các trường này có rỗng không. Nếu có, hiển thị thông báo lỗi.
                if (TextUtils.isEmpty(email)){
                    Toast.makeText(RegisterActivity.this, "Enter Email", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(password)){
                    Toast.makeText(RegisterActivity.this, "Enter Password", Toast.LENGTH_SHORT).show();
                    return;
                }


                // Sử dụng Firebase Authentication để tạo một tài khoản với email và password đã nhập.
                firebaseAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                //Nếu đăng ký thành công (task.isSuccessful()), hiển thị thông báo đăng ký thành công và chuyển đến trang MainActivity.
                                if (task.isSuccessful()){
                                    Toast.makeText(RegisterActivity.this, "Registration Successfully!!!", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                                    startActivity(intent);
                                    finish();
                                }
                                
                                else {
                                    Toast.makeText(RegisterActivity.this, "Authentication Failed!!!", Toast.LENGTH_SHORT).show(); // Nếu không đăng ký thành công, hiển thị thông báo lỗi.
                                }
                            }
                        });


            }
        });



    }
}