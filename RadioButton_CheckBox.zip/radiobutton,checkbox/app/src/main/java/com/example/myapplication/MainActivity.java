package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Khai báo tên biến

    TextView textView;

    RadioButton rbNam, rbNu, rbApple, rbSS, rbDTkhac;

    CheckBox cbMXH, cbGame, cbPhim, cbLL;

    Button btnXN;

    String content ="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Gắn các phần tử từ giao diện người dùng vào các biến tương ứng.
        textView = (TextView) findViewById(R.id.textViewKQ);

        rbNam = (RadioButton) findViewById(R.id.radioBtnNam);
        rbNu = (RadioButton) findViewById(R.id.radioBtnNu);

        rbApple = (RadioButton) findViewById(R.id.radioBtnApple);
        rbSS = (RadioButton) findViewById(R.id.radioBtnSS);
        rbDTkhac = (RadioButton) findViewById(R.id.radioBtnDTkhac);

        cbMXH = (CheckBox) findViewById(R.id.checkBoxMXH);
        cbGame = (CheckBox) findViewById(R.id.checkBoxGame);
        cbPhim = (CheckBox) findViewById(R.id.checkBoxPhim);
        cbLL = (CheckBox)   findViewById(R.id.checkBoxLL);

        btnXN = (Button) findViewById(R.id.button);


        btnXN.setOnClickListener(new View.OnClickListener() { // Đây là một sự kiện lắng nghe. Khi nút này được nhấn, mã bên trong sẽ được thực thi.
            @Override
            public void onClick(View view) { //xử lý sự kiện được thực thi khi btnXN được nhấn. Trong trường hợp này, nó đang xử lý việc tạo nội dung content dựa trên các trạng thái của các nút radio và checkbox.
                content ="";


                // Nếu chọn cái nào thì cái đó sẽ hiển thị ra textview ở dưới
                if (rbNam.isChecked()) {
                    content += rbNam.getText().toString() + "\n";
                }

                if (rbNu.isChecked()) {
                    content += rbNu.getText().toString() + "\n";
                }

                if (rbApple.isChecked()) {
                    content += rbApple.getText().toString() + "\n";
                }

                if (rbSS.isChecked()) {
                    content += rbSS.getText().toString() + "\n";
                }

                if (rbDTkhac.isChecked()) {
                    content += rbDTkhac.getText().toString() + "\n";
                }

                if (cbMXH.isChecked()) {
                    content += cbMXH.getText().toString() + "  \t";
                }

                if (cbGame.isChecked()) {
                    content += cbGame.getText().toString() + "  \t";
                }

                if (cbPhim.isChecked()) {
                    content += cbPhim.getText().toString() + "  \t";
                }

                if (cbLL.isChecked()) {
                    content += cbLL.getText().toString() + "  \t";
                }

                // Xuất KQ ra text view
                if (content.equals("")){
                    Toast.makeText(MainActivity.this, "Không có Dữ Liệu", Toast.LENGTH_SHORT).show();
                }
                else {
                    textView.setText(content);
                }

            }
            });
    }
}