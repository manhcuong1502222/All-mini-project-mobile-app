package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //Khai báo tên biến

    ImageView imgSIU;
    Switch swtSiu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // gán các biến đến các thành phần giao diện trong layout

        imgSIU = (ImageView)    findViewById(R.id.imgMCsiuuu);

        swtSiu = (Switch)   findViewById(R.id.swtAEMAN);

        swtSiu.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // thiết lập một sự kiện lắng nghe cho Switch. Khi trạng thái của Switch thay đổi, sự kiện này sẽ được gọi.
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) { // Đây là phương thức được gọi khi trạng thái của Switch thay đổi.
                if(b) { // b == true
                    Toast.makeText(MainActivity.this, "Man United vô hang", Toast.LENGTH_SHORT).show(); //  Đây là cách tạo và hiển thị một Toast. Nó sẽ hiển thị thông báo ngắn "Man United vô hang".
                    imgSIU.setImageResource(R.drawable.mu); // Đây là cách bạn đang thiết lập hình ảnh của ImageView (imgSIU) thành một nguồn hình ảnh từ tài nguyên (R.drawable.mu). Khi trạng thái của Switch thay đổi thành true, nó sẽ đặt hình ảnh thành nguồn mu.
                }
                else {

                    Toast.makeText(MainActivity.this, "Man City vô địch", Toast.LENGTH_SHORT).show(); // Đây là cách tạo và hiển thị một Toast. Nó sẽ hiển thị thông báo ngắn "Man City vô địch".
                    imgSIU.setImageResource(R.drawable.mc); //  Đây là cách bạn đang thiết lập hình ảnh của ImageView (imgSIU) thành một nguồn hình ảnh từ tài nguyên (R.drawable.mc). Khi trạng thái của Switch thay đổi thành false, nó sẽ đặt hình ảnh thành nguồn mc.

                }
            }
        });


    }
}