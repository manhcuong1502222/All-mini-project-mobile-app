package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    // khai báo các biến sử dụng
    ListView lvEPL;
    ArrayList<String>  arrayEPL; //khai bao mang chua du lieu

    Button btnadd, btnupdate;

    EditText edtClub;

    int possition = -1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Tham chiếu các biến đến các phần tử tương ứng

        lvEPL = (ListView)  findViewById(R.id.listviewEPL);
        arrayEPL = new ArrayList<>();
        btnadd = (Button) findViewById(R.id.btnADD);
        btnupdate = (Button)findViewById(R.id.btnUpdate);
        edtClub = (EditText) findViewById(R.id.editTextClub);


        // add du lieu
        arrayEPL.add("Manchester City");
        arrayEPL.add("Tottenham");
        arrayEPL.add("Liverpool");
        arrayEPL.add("Arsenal");
        arrayEPL.add("Brighton");
        arrayEPL.add("West Ham");

        //ket noi du lieu mang

        ArrayAdapter adapter = new ArrayAdapter(MainActivity.this, android.R.layout.simple_list_item_1, arrayEPL);


        // cho du lieu gan cho listvew de hien thi

        lvEPL.setAdapter(adapter);



        // longclick XOA PHAN TU
        lvEPL.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() { // thiết lập một sự kiện lắng nghe cho việc nhấn giữ lâu trên một item trong Listview
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i , long l) {  // là phương thức được gọi khi một item được nhấn giữ.

                arrayEPL.remove(i); // Xóa phần tử tại vị trí i trong danh sách arrayEPL.
                adapter.notifyDataSetChanged(); // Cập nhật giao diện người dùng (UI) để phản ánh sự thay đổi sau khi xóa item.
                
                return false; // Trả về false để báo cho hệ thống rằng sự kiện này chưa được xử lý hoàn toàn và nó có thể tiếp tục xử lý các sự kiện khác.
            }
        });


        lvEPL.setOnItemClickListener(new AdapterView.OnItemClickListener() { //thiết lập một sự kiện lắng nghe cho việc nhấn vào một item trong ListView.
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) { // là phương thức được gọi khi một item được nhấn.
                edtClub.setText(arrayEPL.get(i)); // Đặt văn bản của edtClub thành giá trị tương ứng với vị trí i trong danh sách arrayEPL.
                possition = i; // Gán giá trị vị trí i cho biến possition, có thể là một biến toàn cục để sử dụng sau này.
            }
        });



        // button add
        btnadd.setOnClickListener(new View.OnClickListener() { // hiết lập một sự kiện lắng nghe cho nút.
            @Override
            public void onClick(View view) { // là phương thức được gọi khi nút được nhấn.

                String clb = edtClub.getText().toString(); // Lấy giá trị chuỗi từ edtClub (có thể là một EditText) và gán cho biến clb.
                arrayEPL.add(clb); // Thêm giá trị của clb vào danh sách arrayEPL.
                adapter.notifyDataSetChanged(); //  Cập nhật giao diện người dùng (UI) để phản ánh sự thay đổi sau khi thêm item mới.

            }
        });

        // buton update
        btnupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                arrayEPL.set(possition, edtClub.getText().toString()); // Thay đổi giá trị tại vị trí possition trong danh sách arrayEPL thành giá trị mới từ edtClub.
                adapter.notifyDataSetChanged(); // Cập nhật giao diện người dùng (UI) để phản ánh sự thay đổi sau khi cập nhật item.
            }
        });



    }
}