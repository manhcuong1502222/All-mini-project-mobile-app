package com.example.myapplication;
public class Device {

    private String nameDV;

    private boolean status;
    int imgDV;
    //tạo Constructor
    public Device(String nameDV, boolean status, int imgDV) {
        this.nameDV = nameDV;
        this.status = status;
        this.imgDV = imgDV;
    }
    public String getNameDV() {
        return nameDV;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public void setImgDV(int imgDV) {this.imgDV = imgDV;}
}

