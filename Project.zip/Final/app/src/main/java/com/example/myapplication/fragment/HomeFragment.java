// Import các thư viện và class cần thiết
package com.example.myapplication.fragment;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.Device;
import com.example.myapplication.MainActivity;
import com.example.myapplication.R;
import com.example.myapplication.Room;
import com.example.myapplication.RoomAdapter;

import java.util.ArrayList;

// Khai báo class HomeFragment kế thừa từ Fragment
public class HomeFragment extends Fragment {

    // Khai báo các biến để tham chiếu đến các phần tử trong layout
    private RecyclerView rcvRoom;
    private View mView;
    private EditText edtRoom;
    private Button btnAddRoom;
    private Button btnRemoveRoom;

    // Khai báo các tham số để truyền vào fragment (nếu cần)
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;
    private MainActivity mMainActivity;
    private RoomAdapter mRoomAdapter;

    // Constructor mặc định
    public HomeFragment() {
        // Required empty public constructor
    }

    // Phương thức tạo mới một instance của HomeFragment và truyền vào các tham số (nếu cần)
    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    // Phương thức được gọi khi fragment được tạo
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    // Phương thức được gọi khi fragment được hiển thị
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate layout của fragment
        mView = inflater.inflate(R.layout.fragment_home, container, false);
        mMainActivity = (MainActivity) getActivity();

        // Lấy tham chiếu đến các phần tử trong layout
        rcvRoom = mView.findViewById(R.id.rcvRoom);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mMainActivity);
        rcvRoom.setLayoutManager(linearLayoutManager);

        // Khởi tạo Adapter và gán danh sách phòng vào Adapter
        mRoomAdapter = new RoomAdapter(Room.globalRooms, new RoomAdapter.IClickItemListener() {
            @Override
            public void onClickItemRoom(Room room, int position) {
                mMainActivity.goToDeviceFragment(room.getName().toString(), position);
            }

            @Override
            public void onLongClickItemRoom(int position) {
                Room.globalRooms.remove(position);
                mRoomAdapter.notifyDataSetChanged();
            }
        });

        // Gán Adapter vào RecyclerView
        rcvRoom.setAdapter(mRoomAdapter);

        // Lấy tham chiếu đến các phần tử trong layout
        edtRoom = mView.findViewById(R.id.edtRoom);
        btnAddRoom = mView.findViewById(R.id.btnAdd);
        btnRemoveRoom = mView.findViewById(R.id.btnRemove);

        // Xử lý sự kiện khi người dùng nhấn nút "Thêm phòng"
        btnAddRoom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Room.globalRooms.add(new Room(edtRoom.getText().toString(), new ArrayList<Device>() {
                    {
                        add(new Device("Device 1", false, R.drawable.device_off));
                        add(new Device("Device 2", false, R.drawable.device_off));
                        add(new Device("Device 3", false, R.drawable.device_off));
                    }
                }));
                mRoomAdapter.notifyDataSetChanged();
            }
        });

        // Xử lý sự kiện khi người dùng nhấn nút "Xóa phòng"
        btnRemoveRoom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String roomRemove = edtRoom.getText().toString();
                for (int i = Room.globalRooms.size() - 1; i >= 0; i--) {
                    Room lRoom = Room.globalRooms.get(i);
                    if (lRoom.getName().toString().equals(roomRemove)) {
                        Room.globalRooms.remove(i);
                        mRoomAdapter.notifyDataSetChanged();
                    }
                }
            }
        });

        // Tạo và cài đặt DividerItemDecoration cho RecyclerView
        RecyclerView.ItemDecoration itemDecoration = new DividerItemDecoration(mMainActivity, DividerItemDecoration.VERTICAL);
        rcvRoom.addItemDecoration(itemDecoration);

        // Trả về giao diện của fragment đã được xử lý
        return mView;
    }
}
