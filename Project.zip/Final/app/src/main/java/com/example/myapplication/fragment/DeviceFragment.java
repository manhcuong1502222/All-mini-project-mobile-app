// Import các thư viện và class cần thiết
package com.example.myapplication.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.Device;
import com.example.myapplication.DeviceAdapter;
import com.example.myapplication.MainActivity;
import com.example.myapplication.R;
import com.example.myapplication.Room;

// Khai báo class DeviceFragment kế thừa từ Fragment
public class DeviceFragment extends Fragment {

    // Khai báo hằng TAG để xác định DeviceFragment đã tạo
    public static final String TAG = DeviceFragment.class.getName();

    // Khai báo các biến để tham chiếu đến các phần tử trong layout
    private RecyclerView rcvDevice;
    private TextView tvNameRinDv;
    private Button btnAddDv;
    private Button btnRemoveDv;
    private EditText edtDevice;
    private View mView;
    private MainActivity mMainActivity;
    DeviceAdapter deviceAdapter;

    // Khai báo các tham số để truyền vào fragment (nếu cần)
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;

    // Constructor mặc định
    public DeviceFragment() {
        // Required empty public constructor
    }

    // Phương thức tạo mới một instance của DeviceFragment và truyền vào các tham số (nếu cần)
    public static DeviceFragment newInstance(String param1, String param2) {
        DeviceFragment fragment = new DeviceFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    // Phương thức được gọi khi fragment được tạo
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    // Phương thức được gọi khi fragment cần hiển thị giao diện
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate layout của fragment
        mView = inflater.inflate(R.layout.fragment_device, container, false);

        // Lấy tham chiếu đến các phần tử trong layout
        tvNameRinDv = mView.findViewById(R.id.tvNameRoomDv);
        btnAddDv = mView.findViewById(R.id.btnAddDv);
        btnRemoveDv = mView.findViewById(R.id.btnRemoveDv);
        edtDevice = mView.findViewById(R.id.edtDevice);
        mMainActivity = (MainActivity) getActivity();
        rcvDevice = mView.findViewById(R.id.rcvDevice);

        // Tạo một GridLayoutManager để quản lý việc hiển thị RecyclerView
        GridLayoutManager gridLayoutManager = new GridLayoutManager(mMainActivity, 2);
        rcvDevice.setLayoutManager(gridLayoutManager);

        // Nhận dữ liệu từ Activity thông qua Bundle
        Bundle bundleReceive = getArguments();
        int index = bundleReceive.getInt("index");
        String NameRinDv = bundleReceive.getString("NameRoom");

        // Hiển thị tên phòng
        tvNameRinDv.setText(NameRinDv);

        // Khởi tạo Adapter và gán danh sách thiết bị của phòng vào Adapter
        deviceAdapter = new DeviceAdapter(Room.globalRooms.get(index).getListDevice(), new DeviceAdapter.IClickItemListener() {
            @Override
            public void onLongClickItemRoom(int position) {
                Room.globalRooms.get(index).removeDevice(position);
                deviceAdapter.notifyDataSetChanged();
            }
        });

        // Gán Adapter vào RecyclerView
        rcvDevice.setAdapter(deviceAdapter);

        // Xử lý sự kiện khi người dùng nhấn nút "Thêm thiết bị"
        btnAddDv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Room.globalRooms.get(index).addDevice(new Device(edtDevice.getText().toString(), false, R.drawable.device_off));
                deviceAdapter.notifyDataSetChanged();
            }
        });

        // Xử lý sự kiện khi người dùng nhấn nút "Xóa thiết bị"
        btnRemoveDv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String deviceRemove = edtDevice.getText().toString();
                for (int i = 0; i < Room.globalRooms.get(index).getNumber(); i++) {
                    if (Room.globalRooms.get(index).getListDevice().get(i).getNameDV().equals(deviceRemove)) {
                        Room.globalRooms.get(index).removeDevice(i);
                        deviceAdapter.notifyDataSetChanged();
                        break;
                    }
                }
            }
        });

        // Trả về giao diện của fragment đã được xử lý
        return mView;
    }
}
