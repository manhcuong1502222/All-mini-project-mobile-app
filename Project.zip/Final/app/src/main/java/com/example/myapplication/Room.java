package com.example.myapplication;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Room implements Serializable {

    private String name;
    private List<Device> listDevice;

    // Constructor của lớp Room
    public Room(String name, List<Device> listDevice) {
        this.name = name;
        this.listDevice = listDevice;
    }

    // Getter trả về tên của phòng
    public String getName() {
        return name;
    }
    // Setter để thiết lập tên của phòng
    public void setName(String name) {
        this.name = name;
    }
    // Getter trả về danh sách các thiết bị trong phòng
    public List<Device> getListDevice() {
        return listDevice;
    }
    // Setter để thiết lập danh sách các thiết bị trong phòng
    public void setListDevice(List<Device> listDevice) {
        this.listDevice = listDevice;
    }

    public void addDevice(Device dv) {
        listDevice.add(dv);
    }
    // Phương thức để xóa một thiết bị khỏi phòng dựa trên chỉ số
    public void removeDevice(int index) {
        listDevice.remove(index);
    }
    // Phương thức để lấy số lượng thiết bị trong phòng
    public int getNumber() {
        return listDevice.size();
    }

    // Danh sách các phòng toàn cục (có thể truy cập từ bất kỳ đâu)
    public static List<Room> globalRooms = new ArrayList<Room>();
}
