package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RoomAdapter extends RecyclerView.Adapter<RoomAdapter.RoomViewHolder> {
    private Context mContext;
    private IClickItemListener mIClickItemListener;
    public interface IClickItemListener {
        void onClickItemRoom(Room room, int position);
        void onLongClickItemRoom(int position);
    }
    private List<Room> mListRoom;

    // Constructor của RoomAdapter, nhận danh sách các phòng và một đối tượng IClickItemListener
    public RoomAdapter(List<Room> mListRoom, IClickItemListener listener) {
        this.mListRoom = mListRoom;
        this.mIClickItemListener = listener;
    }
    // Phương thức tạo view holder mới
    @NonNull
    @Override
    public RoomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.room_layout, parent, false);
        return new RoomViewHolder(view);
    }

    // Phương thức gắn dữ liệu vào view holder
    @Override
    public void onBindViewHolder(@NonNull RoomViewHolder holder, int position) {
        Room room = mListRoom.get(position);
        int itemPosition = holder.getAdapterPosition();
        if(room == null) {
            return;
        }
        holder.tvName.setText(room.getName());
        holder.tvNumber.setText("Devices: " + room.getNumber());
        holder.tvName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mIClickItemListener.onClickItemRoom(room, itemPosition);
            }
        });
        holder.tvName.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                mIClickItemListener.onLongClickItemRoom(itemPosition);
                return true;
            }
        });
    }

    // Phương thức trả về số lượng phòng
    @Override
    public int getItemCount() {
        if(mListRoom != null) {
            return mListRoom.size();
        }
        return 0;
    }


    // Lớp RoomViewHolder đại diện cho một view holder của RecyclerView
    public class RoomViewHolder extends RecyclerView.ViewHolder {
        private LinearLayout layoutRoom;
        private TextView tvName;
        private TextView tvNumber;


        // Constructor của RoomViewHolder, khởi tạo các view
        public RoomViewHolder(@NonNull View itemView) {
            super(itemView);
            layoutRoom = itemView.findViewById(R.id.layoutRoom);
            tvName = itemView.findViewById(R.id.tvName);
            tvNumber = itemView.findViewById(R.id.tvNumber);
        }
    }
}
