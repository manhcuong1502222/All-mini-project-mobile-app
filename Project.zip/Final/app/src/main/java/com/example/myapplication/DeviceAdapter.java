package com.example.myapplication;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DeviceAdapter extends RecyclerView.Adapter<DeviceAdapter.DeviceViewHolder> {
    private Context mContext;
    private List<Device> mListDevice;
    private DeviceAdapter.IClickItemListener mIClickItemListener;
    public interface IClickItemListener {
        void onLongClickItemRoom(int position);
    }
    private Drawable drawable;
    public DeviceAdapter(List<Device> list, DeviceAdapter.IClickItemListener listener) {
        this.mListDevice = list;
        this.mIClickItemListener = listener;
    }

// Phương thức tạo ViewHolder, đây là nơi tạo ra các view cho mỗi mục trong RecyclerView

    @NonNull
    @Override
    public DeviceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.device_layout, parent, false);
        return new DeviceViewHolder(view);
    }

    // Phương thức này được gọi khi RecyclerView cần hiển thị dữ liệu cho một ViewHolder cụ thể
    @Override
    public void onBindViewHolder(@NonNull DeviceViewHolder holder, int position) {
        int itemPosition = holder.getAdapterPosition(); // Lấy vị trí của mục trong Adapter
        Device device = mListDevice.get(position);  // Lấy thiết bị tương ứng với vị trí
        if(device == null) {
            return; // Nếu thiết bị không tồn tại, không làm gì cả
        }

        // Gán thông tin của thiết bị vào các thành phần trong ViewHolder
        holder.tvNameDv.setText(device.getNameDV());
        holder.swControl.setChecked(device.getStatus());
        if(device.getStatus())
            holder.imgDv.setImageResource(R.drawable.device_on);
        else
            holder.imgDv.setImageResource(R.drawable.device_off);
        holder.tvNameDv.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                mIClickItemListener.onLongClickItemRoom(itemPosition);
                return true;
            }
        });

        // Xử lý sự kiện khi người dùng giữ lâu trên một mục
        holder.swControl.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                device.setStatus(isChecked);
                if(isChecked)
                    holder.imgDv.setImageResource(R.drawable.device_on);
                else
                    holder.imgDv.setImageResource(R.drawable.device_off);
            }
        });
    }

    // Phương thức trả về số lượng mục trong danh sách thiết bị

    @Override
    public int getItemCount() { //tạo phương thức đếm số mục
        if(mListDevice != null) {
            return mListDevice.size();
        }
        return 0;
    }

    // ViewHolder là một lớp dùng để lưu trữ các thành phần giao diện của một mục trong RecyclerView
    public class DeviceViewHolder extends RecyclerView.ViewHolder {
        private TextView tvNameDv;
        private Switch swControl;
        private ImageView imgDv;

        // Constructor để khởi tạo ViewHolder và gán tham chiếu đến các thành phần trong layout
        public DeviceViewHolder(@NonNull View itemView) {
            super(itemView);

            tvNameDv = itemView.findViewById(R.id.tvNameDv);
            swControl = itemView.findViewById(R.id.swControl);
            imgDv = itemView.findViewById(R.id.imgDevice);
        }
    }
}
