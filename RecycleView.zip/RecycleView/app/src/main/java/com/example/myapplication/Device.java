package com.example.myapplication;
//tạo class cho thiết bị
public class Device {
    //Gồm 2 thuộc tính là tên thiết bị nameDV và trạng thái thiết bị status
    private String nameDV;

    private boolean status;
    //tạo Constructor
    public Device(String nameDV, boolean status) {
        this.nameDV = nameDV;
        this.status = status;
    }
    //tạo các hàm get và set
    public String getNameDV() {
        return nameDV;
    }


    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}

