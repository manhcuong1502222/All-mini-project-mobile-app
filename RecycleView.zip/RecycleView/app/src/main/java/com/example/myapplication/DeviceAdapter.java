package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DeviceAdapter extends RecyclerView.Adapter<DeviceAdapter.DeviceViewHolder> {
    //Tạo thuộc tính cho DeviceAdapter gồm mContext và mListDevice
    private Context mContext;
    private List<Device> mListDevice;

    //tạo Constructor
    public DeviceAdapter(List<Device> list) {
        this.mListDevice = list;
    }


    @NonNull
    @Override
    public DeviceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.device_layout, parent, false);
        return new DeviceViewHolder(view);
    } //tạo ViewHolder từ giao diện device_layout mà ta đã thiết kế cho các mục trong RecyclerView

    @Override
    public void onBindViewHolder(@NonNull DeviceViewHolder holder, int position) {
        Device device = mListDevice.get(position);
        if(device == null) {
            return;
        }
        holder.tvNameDv.setText(device.getNameDV());
        holder.swControl.setChecked(device.getStatus());
        //Lấy từng phần tử trong danh sách thiết bị và set tên, trạng thái switch cho các TextView và Switch để hiển thị
        holder.swControl.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { //tạo phương thức khi trạng thái Switch thay đổi
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                device.setStatus(isChecked); //khi trạng thái thiết bị thay đổi thì trạng thái thiết bị tương ứng trong mảng sẽ được đặt lại
            }
        });
    }

    @Override
    public int getItemCount() { //tạo phương thức đếm số mục
        if(mListDevice != null) {
            return mListDevice.size();
        }
        return 0;
    }

    public class DeviceViewHolder extends RecyclerView.ViewHolder { //tạo lớp DeviceViewHolder để lưu trữ các thành phần cấu tạo nên giao diện của một mục trong RecylerView
        //Gồm 2 thành phần là TextView tvNameDv và Switch swControl
        private TextView tvNameDv;
        private Switch swControl;
        //tạo Constructor ánh xạ các phần tử từ layout
        public DeviceViewHolder(@NonNull View itemView) {
            super(itemView);

            tvNameDv = itemView.findViewById(R.id.tvNameDv);
            swControl = itemView.findViewById(R.id.swControl);
        }
    }
}
