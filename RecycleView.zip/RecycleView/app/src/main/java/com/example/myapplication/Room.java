package com.example.myapplication;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

//tạo class Room chứa các phòng
public class Room implements Serializable { //lớp room được Serializable để có thể bundle dữ liệu
    //tạo cho Room 2 thuộc tính gồm tên phòng (name) và danh sách các thiết bị của phòng (listDevice)
    private String name;
    private List<Device> listDevice;

    //tạo Constructor
    public Room(String name, List<Device> listDevice) {
        this.name = name;
        this.listDevice = listDevice;
    }
    //tạo các hàm get/set
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Device> getListDevice() {
        return listDevice;
    }

    public void setListDevice(List<Device> listDevice) {
        this.listDevice = listDevice;
    }

    public void addDevice(Device dv) {
        listDevice.add(dv);
    } //tạo hàm thêm thiết bị cho phòng

    public void removeDevice(int index) {
        listDevice.remove(index);
    } //tạo hàm xóa thiết bị khỏi phòng

    public int getNumber() {
        return listDevice.size();
    } //tạo hàm trả về số thiết bị có trong phòng

    public static List<Room> globalRooms = new ArrayList<Room>(); //định nghĩa danh sách Room để có thể truy cập từ bất cứ đâu trong ứng dụng
}
