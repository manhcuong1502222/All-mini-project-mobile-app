package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RoomAdapter extends RecyclerView.Adapter<RoomAdapter.RoomViewHolder> { //tạo lớp RoomAdapter kế thừa từ RecyclerView.Adapter sử dụng ViewHolder kiểu RoomViewHolder
    private Context mContext;
    private IClickItemListener mIClickItemListener;
    public interface IClickItemListener { //định nghĩa interface IClickItemListener với phương thức onClickItemRoom để chuyển tới màn hình hiển thị thiết bị
        void onClickItemRoom(Room room, int position);
    }
    private List<Room> mListRoom;
    public RoomAdapter(List<Room> mListRoom, IClickItemListener listener) {
        this.mListRoom = mListRoom;
        this.mIClickItemListener = listener;
    }

    @NonNull
    @Override
    public RoomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) { //Phương thức này được gọi khi RecyclerView cần tạo một ViewHolder mới cho một mục dữ liệu
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.room_layout, parent, false);
        return new RoomViewHolder(view);
        //chuyển đổi giao diện room_layout mà ta thiết kế cho Room thành view để tạo ViewHolder mới khi RecyclerView hiển thị các mục dữ liệu
    }

    @Override
    public void onBindViewHolder(@NonNull RoomViewHolder holder, int position) { //phương thức này đc gọi để hiển thị dữ liệu trong RecyclerView
        Room room = mListRoom.get(position); //lấy một room dựa trên vị trí trong mảng
        int itemPosition = holder.getAdapterPosition(); //lưu vị trí của Room đó vào biến itemPosition
        if(room == null) {
            return;
        } //nếu room trống tức không có phòng nào được tạo thì phương thức kết thúc ở đây
        holder.tvName.setText(room.getName()); //Set tên phòng vào tvName tức TextView hiển thị tên phòng mà ta tạo bên layout
        holder.tvNumber.setText("Device: " + room.getNumber()); // Tương tự, set số thiết bị vào tvNumber
        holder.tvName.setOnClickListener(new View.OnClickListener() { //tạo phương thức khi ấn vào tên của phòng
            @Override
            public void onClick(View v) {
                mIClickItemListener.onClickItemRoom(room, itemPosition); //khi ấn vào tên phòng thì hàm onClickItemRoom của mIClickItemListener sẽ được gọi để chuyển tới màn hình thiết bị
            }
        });
    }
    @Override
    public int getItemCount() { //phương thức này trả về số lượng mục dánh sách
        if(mListRoom != null) {
            return mListRoom.size();
        }
        return 0;
    }

    public class RoomViewHolder extends RecyclerView.ViewHolder { //tạo lớp RoomViewHolder để lưu trữ các thành phần cấu tạo nên giao diện của một mục trong RecylerView

        private LinearLayout layoutRoom;
        private TextView tvName;
        private TextView tvNumber;

        public RoomViewHolder(@NonNull View itemView) {
            super(itemView);
            layoutRoom = itemView.findViewById(R.id.layoutRoom);
            tvName = itemView.findViewById(R.id.tvName);
            tvNumber = itemView.findViewById(R.id.tvNumber);
        }
    }
}
