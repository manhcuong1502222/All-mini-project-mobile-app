package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction(); //tạo một fragmentTransaction để thêm Fragment vào Activity và quản lý thao tác với Fragment
        fragmentTransaction.add(R.id.content_frame, new HomeFragment()); //thêm một HomeFragment vào Activity ở phần tử có id content_frame trong layout của MainActivity
        fragmentTransaction.commit(); //hiển thị Fragment được thêm vào trên giao diện
    }
    public void goToDeviceFragment(String nameRoom, int index) { //tạo phương thức chuyển hướng Fragment từ Room sang Device
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction(); //tương tự cũng tạo một fragmentTransaction để thêm Fragment vào Activity và quản lý thao tác với Fragment
        DeviceFragment deviceFragment = new DeviceFragment(); //tạo DeviceFragment mới

        //tạo Bundle để chuyển dữ liệu từ HomeFragment sang DeviceFragment
        Bundle bundle = new Bundle();
        bundle.putString("NameRoom", nameRoom);
        bundle.putInt("index", index);
        //chuyển dữ liệu gồm tên phòng (key:NameRoom) và vị trí của phòng (key:index)
        deviceFragment.setArguments(bundle); //đặt Bundle chứa dữ liệu vào DeviceFragment để DeviceFragment có thể truy cập và sử dụng dữ liệu này sau khi được tạo


        fragmentTransaction.replace(R.id.content_frame, deviceFragment); //thay thế HomeFragment bằng DeviceFragment vào layout content_frame
        fragmentTransaction.addToBackStack(DeviceFragment.TAG); //thêm DeviceFragment vào backstack để quay lại HomeFragment
        fragmentTransaction.commit(); //thực hiện chuyển từ HomeFragment sang DeviceFragment
    }
}