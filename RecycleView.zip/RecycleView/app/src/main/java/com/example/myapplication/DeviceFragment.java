package com.example.myapplication;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class DeviceFragment extends Fragment {
    public static final String TAG = DeviceFragment.class.getName(); //tạo hằng TAG để xác định DeviceFragment đã tạo
    //tạo các biến để tham chiếu đến các phần tử ở layout
    private RecyclerView rcvDv;
    private TextView tvNameDv;
    private Button btnBack;
    private Button btnAddDv;
    private Button btnRemoveDv;
    private EditText edtDv;
    private View mView;
    private MainActivity mMainActivity;


    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    private String mParam1;
    private String mParam2;

    public DeviceFragment() {
    }


    public static DeviceFragment newInstance(String param1, String param2) {
        DeviceFragment fragment = new DeviceFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        mView = inflater.inflate(R.layout.fragment_device, container, false); //inflate layout fragment_device vào biến mView


        tvNameDv = mView.findViewById(R.id.tvNameRinDv);
        btnBack = mView.findViewById(R.id.btnBack);
        btnAddDv = mView.findViewById(R.id.btnAddDv);
        btnRemoveDv = mView.findViewById(R.id.btnRemoveDv);
        edtDv = mView.findViewById(R.id.edtDevice);

        mMainActivity = (MainActivity) getActivity(); //tham chiếu đến Activity chứa Fragment
        rcvDv = mView.findViewById(R.id.rcvDevice);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(mMainActivity, 3); //tạo một GridLayoutManager
        rcvDv.setLayoutManager(gridLayoutManager); //thiết lập GridLayoutManager làm LayoutManager cho RecyclerView của Device


        Bundle bundleReceive = getArguments(); //tạo một bundle là bundleReceive để lấy dữ liệu truyền qua từ HomeFragment
        int index = bundleReceive.getInt("index"); //lưu giá trị thứ tự phòng vào biến index
        String NameRinDv = bundleReceive.getString("NameRoom"); //lưu tên phòng vào biến NameRinDv
        tvNameDv.setText(NameRinDv); //hiển thị tên phòng lên TextView
        DeviceAdapter deviceAdapter = new DeviceAdapter(Room.globalRooms.get(index).getListDevice()); //tạo một DeviceAdapter với danh sách thiết bị tương ứng của phòng được chọn
        rcvDv.setAdapter(deviceAdapter); //set DeviceAdapter cho RecyclerView



        btnAddDv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Room.globalRooms.get(index).addDevice(new Device(edtDv.getText().toString(), false));
                deviceAdapter.notifyDataSetChanged();
            }
        });


        btnRemoveDv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String deviceRemove = edtDv.getText().toString();
                for (int i = 0; i < Room.globalRooms.get(index).getNumber(); i++) {
                    if (Room.globalRooms.get(index).getListDevice().get(i).getNameDV().equals(deviceRemove)) {
                        Room.globalRooms.get(index).removeDevice(i);
                        deviceAdapter.notifyDataSetChanged();
                        break;
                    }
                }
            }
        });



        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getFragmentManager() != null)
                    getFragmentManager().popBackStack();
            }
        });



        return mView;
    }
}