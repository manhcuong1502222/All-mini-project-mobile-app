package com.example.myapplication;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {
    //tạo các biến để tham chiếu đến các phần tử ở layout
    private RecyclerView rcvRoom;
    private View mView;
    private EditText edtRoom;
    private Button btnAddRoom;
    private Button btnRemoveRoom;


    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private MainActivity mMainActivity;

    public HomeFragment() {
        // Required empty public constructor
    }


    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mView = inflater.inflate(R.layout.fragment_home, container, false); //inflate layout fragment_home vào biến mView
        mMainActivity = (MainActivity) getActivity(); //Dòng này lấy tham chiếu đến Activity chứa Fragment thông qua getActivity() và ép kiểu thành MainActivity,  giúp truy cập các phương thức và thành phần của Activity từ trong Fragment
        rcvRoom = mView.findViewById(R.id.rcvRoom); //lấy tham chiếu RecyclerView của Room
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mMainActivity);
        rcvRoom.setLayoutManager(linearLayoutManager);
        //tạo và cài đặt LinearLayoutManager cho rcvRoom
        RoomAdapter roomAdapter = new RoomAdapter(Room.globalRooms, new RoomAdapter.IClickItemListener() { //tạo một RoomAdapter truyền vào danh sách Room globalRooms và một interface chứa phương thức onClickItemRoom sẽ thực hiện goToDeviceFragment từ Main Activity
            @Override
            public void onClickItemRoom(Room room, int position) {
                mMainActivity.goToDeviceFragment(room.getName().toString(),position);
            }
        });
        rcvRoom.setAdapter(roomAdapter); //set Adapter đã tạo cho RecyclerView
        //tham chiếu đến EditText và nút nhấn
        edtRoom = mView.findViewById(R.id.edtRoom);
        btnAddRoom = mView.findViewById(R.id.btnAdd);
        btnRemoveRoom = mView.findViewById(R.id.btnRemove);



        btnAddRoom.setOnClickListener(new View.OnClickListener() {//tạo sự kiện khi nhấn vào nút Add Room
            @Override
            public void onClick(View v) {
                Room.globalRooms.add(new Room(edtRoom.getText().toString(),new ArrayList<>()));
                roomAdapter.notifyDataSetChanged();
                //Thêm một Room vào globalRooms với tên phòng được lấy từ Edit Text edtRoom và danh sách thiết bị là rỗng
            }
        });



        btnRemoveRoom.setOnClickListener(new View.OnClickListener() { //tạo sự kiện khi click vào nút Remove Room
            @Override
            public void onClick(View v) {
                String roomRemove = edtRoom.getText().toString(); //lấy tên phòng muốn xóa lưu vào roomRemove
                for (int i = Room.globalRooms.size() - 1; i >= 0; i--) {
                    Room lRoom = Room.globalRooms.get(i);
                    if (lRoom.getName().toString().equals(roomRemove)) {
                        Room.globalRooms.remove(i);
                        roomAdapter.notifyDataSetChanged();
                        //Kiểm tra từng phần tử trong globalRooms, nếu có Room có tên giống với tên phòng cần xóa thì sẽ xóa nó
                    }
                }
            }
        });



        RecyclerView.ItemDecoration itemDecoration = new DividerItemDecoration(mMainActivity, DividerItemDecoration.VERTICAL);
        rcvRoom.addItemDecoration(itemDecoration);
        //thiết lập một ItemDecoration cho RecyclerView để hiển thị các đường phân cách  giữa các mục trong danh sách
        return mView; //trả về mView đã được inflate
    }
}