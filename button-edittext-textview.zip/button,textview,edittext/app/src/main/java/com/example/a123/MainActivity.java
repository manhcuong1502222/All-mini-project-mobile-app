package com.example.a123;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    // khai báo biến
    TextView txtNoiDung;
    Button btntinh, btnxoa;

    EditText edt_a, edt_b, edt_KQ;

    int a, b, sum;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ánh xạ
       txtNoiDung = (TextView) findViewById(R.id.textView);
       btntinh = (Button) findViewById(R.id.btnKQ);
       btnxoa = (Button) findViewById(R.id.btnXoa);
       edt_a = (EditText) findViewById(R.id.edt_a);
       edt_b = (EditText) findViewById(R.id.edt_b);
       edt_KQ = (EditText) findViewById(R.id.edt_KQ);

       // coding

    btntinh.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            //Đây là cách bạn lấy giá trị từ hai trường văn bản edt_a và edt_b và chuyển đổi chúng thành số nguyên để thực hiện phép cộng.
            a = Integer.parseInt(edt_a.getText().toString());
            b = Integer.parseInt(edt_b.getText().toString());
            sum = a+b; // Tính tổng của a và b.
            edt_KQ.setText(""); // Xóa văn bản hiện có trong edt_KQ.
            // Hiện thị tổng
            edt_KQ.setText(edt_KQ.getText().toString() + sum);

        }
    });

    btnxoa.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            // Xóa văn bản hiện có trong các trường
            edt_a.setText("");
            edt_b.setText("");
            edt_KQ.setText("");
            edt_a.setFocusable(true); //  Đặt trường văn bản edt_a có thể tập trung vào để người dùng có thể nhập lại giá trị mới.

        }
    });


    }
}