package com.example.constraint;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    // Khai báo các biến sử dụng
    Button btn_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // tham chiếu các biến đến các phần tử tương ứng
        btn_login = (Button) findViewById(R.id.btnLogin);

        btn_login.setOnClickListener(new View.OnClickListener() { //  Đây là cách bạn đang thiết lập một sự kiện lắng nghe cho nút. Khi nút này được nhấn, sự kiện onClick sẽ được kích hoạt.
            @Override
            public void onClick(View view) { //  Đây là phương thức được gọi khi nút được nhấn. Có một tham số view, đó chính là nút mà người dùng đã nhấn.

                Intent intent = new Intent(MainActivity.this, SecondActivity.class); // Đây là cách bạn tạo một Intent. Intent được sử dụng để khởi đầu các hoạt động (Activities) mới trong Android. Trong trường hợp này, bạn đang tạo một Intent để chuyển từ MainActivity đến SecondActivity .

                startActivity(intent); // Đây là cách bạn bắt đầu một hoạt động mới sử dụng Intent. Trong trường hợp này, bạn đang bắt đầu hoạt động được chỉ định trong Intent, tức là MainActivity.

            }
        });

    }
}